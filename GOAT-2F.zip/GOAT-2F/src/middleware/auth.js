const jwt = require('jsonwebtoken');
const verifyToken = (req, res, next) => {

    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1]; // Extrai o token do cabeçalho
    if (!token) return res.status(401).send('Acesso negado. Token não fornecido.' );

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        
        req.user = decoded; // Armazena os dados do usuário decodificados no objeto req

        next(); // Passa para a próxima função de middleware ou rota
    }
    catch (err) {
        return res.status(403).send('Token inválido.');
    }  
};

module.exports = verifyToken;
