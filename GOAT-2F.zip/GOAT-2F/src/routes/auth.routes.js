const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const userDb = require('../utils/usersDb');

router.post('/login', async (req, res) => {

    const { email, password } = req.body;

    const user = userDb.find( u => u.email === email);
    if (!user) return res.status(401).json({ message: 'Credenciais inválida.'});

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(401).json({ message: "Credenciais invalidas." });

    const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, { expiresIn: '1h' });
    
    res.json({ token });

});
module.exports = router;